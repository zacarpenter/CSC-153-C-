﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project
{
    public partial class GuessLetter : Form
    {
        public GuessLetter()
        {
            InitializeComponent();
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            WoF guess = new WoF();

            guess.GuessALetter();

            
        } // end method

        private void GuessLetter_Load(object sender, EventArgs e)
        {

        }
    } // end class
} // end namespace
