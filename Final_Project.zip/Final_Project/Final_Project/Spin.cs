﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Final_Project
{
    class Spin
    {
        // field representing the spin
        private int wheelSpin;

        Random rand = new Random();

        // Constructor
        public Spin()
        {
            wheelSpin = 0;
        }

        // Spin Wheel method simulates contestant spin
        public void SpinWheel()
        { 
            // use a random number to determine the wheel spin
            if (rand.Next(9) == 0)
            {
                wheelSpin = 0;
            }
            else if (rand.Next(9) == 1)
            {
                wheelSpin = 1;
            }
            else if (rand.Next(9) == 2)
            {
                wheelSpin = 2;
            }
            else if (rand.Next(9) == 3)
            {
                wheelSpin = 3;
            }
            else if (rand.Next(9) == 4)
            {
                wheelSpin = 4;
            }
            else if (rand.Next(9) == 5)
            {
                wheelSpin = 5;
            }
            else if (rand.Next(9) == 6)
            {
                wheelSpin = 6;
            }
            else if (rand.Next(9) == 7)
            {
                wheelSpin = 7;
            }
            else if (rand.Next(9) == 8)
            {
                wheelSpin = 8;
            }
            else if (rand.Next(9) == 9)
            {
                wheelSpin = 9;
            }
        } // end method

        public int GetSpin()
        {
            return wheelSpin;
        } // end method

    } // end class
} // end namespace
