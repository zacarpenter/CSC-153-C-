﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Final_Project
{
    public partial class WoF : Form
    {
        public WoF()
        {
            InitializeComponent();
        }

        // access the Spin class
        Spin spin = new Spin();

        // access Guess Letter form
        GuessLetter guess = new GuessLetter();

        // initialize the answer
        private string answer = "NORTH CAROLINA";

        // initialize the available letter list
        public string availableLetters;

        // initialize the current player array
        private string[] currentPlayer = new string[] { "Player 1", "Player 2", "Player 3" };

        // initialize the player amounts array
        private int[] playerAmounts = new int[] { 0, 0, 0 };

        // initialize the playerGuess entry
        private string playerGuess;

        private void WoF_Load(object sender, EventArgs e)
        {
            // availableLetters takes the value of the label
            availableLetters = lblLetters.Text;
            //MessageBox.Show(availableLetters);
            // assign the currentPlayer to the label
            lblCurrentPlayer.Text = currentPlayer[0].ToString() + " - Spin or Solve"; 
        }


        public void GuessALetter()
        {
            try
            {
                // convert the text box to Upper
                guess.txtGuess.Text.ToUpper();
                // assign our variable playerGuess to the value entered in the textbox
                playerGuess = guess.txtGuess.Text;

                spin.GetSpin();

                // if for each spin index?
                if (playerGuess == "A")
                {
                    if (availableLetters.Contains('A'))
                    {
                        // insert amount here
                        MessageBox.Show("There are 2 A's in the puzzle worth: ");
                    }
                    
                    // edit the available letters label
                    //lblLetters.Text = availableLetters.Insert(0, " ");
                    // set the second form's available letters to match the first
                    //guess.GuesslblLetters.Text = lblLetters.Text;
                }
                
            } // end try
            catch
            {
                MessageBox.Show("Please enter a valid letter.");    
            } // end catch
        } // end method

        private void btnSpin_Click(object sender, EventArgs e)
        {

            spin.SpinWheel();

            if (spin.GetSpin() < 8)
            {
                if (spin.GetSpin() == 0)
                {
                    MessageBox.Show(currentPlayer[0].ToString() + " landed on $100");
                    guess.ShowDialog();
                }
                if (spin.GetSpin() == 1)
                {
                    MessageBox.Show(currentPlayer + " landed on $300");
                    guess.ShowDialog();
                }
                if (spin.GetSpin() == 2)
                {
                    MessageBox.Show(currentPlayer + " landed on $500");
                    guess.ShowDialog();
                }
                if (spin.GetSpin() == 3)
                {
                    MessageBox.Show(currentPlayer + " landed on $700");
                    guess.ShowDialog();
                }
                if (spin.GetSpin() == 4)
                {
                    MessageBox.Show(currentPlayer + " landed on $900");
                    guess.ShowDialog();
                }
                if (spin.GetSpin() == 5)
                {
                    MessageBox.Show(currentPlayer + " landed on $2000");
                    guess.ShowDialog();
                }
                if (spin.GetSpin() == 6)
                {
                    MessageBox.Show(currentPlayer + " landed on $3000");
                    guess.ShowDialog();
                }
                if (spin.GetSpin() == 7)
                {
                    MessageBox.Show(currentPlayer + " landed on $5000");
                    guess.ShowDialog();
                }
            }
            else if (spin.GetSpin() == 8)
            {
                MessageBox.Show(currentPlayer + " landed on -$1000. Next player's turn.");
                // next player
            }
            else if (spin.GetSpin() == 9)
            {
                MessageBox.Show(currentPlayer + " landed on $0. Next player's turn");
                // next player
            }
        } // end method

    } // end class
} // end namespace
